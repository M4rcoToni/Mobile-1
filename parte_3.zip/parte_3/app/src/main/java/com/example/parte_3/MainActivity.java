package com.example.parte_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText idade;
    private EditText altura;
    private EditText peso;

    private TextView res;
    private TextView cat;

    private TextView sau;
    private TextView abaixo;
    private TextView sobre;

    private Button calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idade = findViewById(R.id.idade);
        altura = findViewById(R.id.altura);
        peso = findViewById(R.id.peso);
        calcular = findViewById(R.id.calc);

        cat = findViewById(R.id.categoria);
        res = findViewById(R.id.res);

        sau = findViewById(R.id.saudavel);
        abaixo = findViewById(R.id.abaixo);
        sobre  = findViewById(R.id.sobrepeso);

        calcular.setOnClickListener(this);
        getSupportActionBar().hide();

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.calc) {
            if(idade.getText().length() <= 0){
                Toast.makeText(getApplicationContext(), "Digite sua Idade e toque novamente", Toast.LENGTH_LONG).show();
            }else if(peso.getText().length() <= 0) {
            Toast.makeText(getApplicationContext(), "Digite seu Peso e toque novamente", Toast.LENGTH_LONG).show();
            }else if(altura.getText().length() <= 0){
                Toast.makeText(getApplicationContext(), "Digite sua Altura e toque novamente", Toast.LENGTH_LONG).show();
            }else{
                resetColors();

                DecimalFormat formatador = new DecimalFormat("0.0");
                String fim = ""+formatador.format(imc());
                res.setText(fim);

                resultadoFinal(imc());
            }
        }
    }
    public Double imc(){
        //String id = idade.getText().toString();
        String al = altura.getText().toString();
        double altura = Double.parseDouble(al);
        String pe = peso.getText().toString();
        double peso = Double.parseDouble(pe);

        double almulti = altura * altura;

        double resultado = peso / almulti;

        return resultado;
    }

    public void resetColors(){
        abaixo.setBackgroundColor(getResources().getColor(R.color.gray));
        sau.setBackgroundColor(getResources().getColor(R.color.gray));
        sobre.setBackgroundColor(getResources().getColor(R.color.gray));
    }

    public void resultadoFinal(double resultado){
        if (resultado <= 15.9){
            cat.setText("Magreza Grave");
            abaixo.setBackgroundColor(getResources().getColor(R.color.yellow));
        }else  if (resultado >= 16 && resultado <= 16.9){
            cat.setText("Magreza Moderada");
            abaixo.setBackgroundColor(getResources().getColor(R.color.yellow));
        }else  if (resultado >= 17 && resultado <= 18.4){
            cat.setText("Magreza Leve");
            abaixo.setBackgroundColor(getResources().getColor(R.color.yellow));
        }else  if (resultado >= 18.5 && resultado <= 24.9){
            cat.setText("Saudável");
            sau.setBackgroundColor(getResources().getColor(R.color.green));
        }else  if (resultado >= 25 && resultado <= 29.9){
            cat.setText("Sobrepeso");
            sobre.setBackgroundColor(getResources().getColor(R.color.red));
        }else  if (resultado >= 30 && resultado <= 34.9){
            cat.setText("Obesidade Grau |");
            sobre.setBackgroundColor(getResources().getColor(R.color.red));
        }else  if (resultado >= 35 && resultado <= 39.9){
            cat.setText("Obesidade Grau ||");
            sobre.setBackgroundColor(getResources().getColor(R.color.red));
        }else  if (resultado >= 40){
            cat.setText("Obesidade Grau |||");
            sobre.setBackgroundColor(getResources().getColor(R.color.red));
        }
    }
}