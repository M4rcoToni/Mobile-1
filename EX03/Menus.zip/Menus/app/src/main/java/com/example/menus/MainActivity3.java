package com.example.menus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {
    private ProgressBar prog;
    private EditText login;
    private EditText senha;
    private int salva;
    private int continua;
    private Button entrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senha);
        prog = findViewById(R.id.pro);
        getSupportActionBar().hide();
        entrar = findViewById(R.id.button);
        entrar.setOnClickListener(this);
        prog.setMax(5);
        senha.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                continua = salva + start;
                prog.setProgress(continua);
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (login.getText().toString().equals("admin") && senha.getText().toString().equals("admin")){
            Intent welcome = new Intent(getApplicationContext(), MainActivity3v2.class);
            Bundle dados = new Bundle();
            String usuario = login.getText().toString();
            dados.putString("login", usuario);
            welcome.putExtras(dados);
            startActivity(welcome);
        }else{
            Toast.makeText(getApplicationContext(), "Login ou Senha Incorretos!", Toast.LENGTH_LONG).show();
        }
    }

}