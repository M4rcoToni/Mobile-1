package com.example.menus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
public class MainActivity4v2 extends AppCompatActivity {
    private EditText lembrete;
    private Button define;
    private String mensagem;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity4v2);
        lembrete = findViewById(R.id.lembrete);
        define = findViewById(R.id.definir);

        getSupportActionBar().hide();

        define.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mensagem = lembrete.getText().toString();
                Intent recebe = new Intent();
                recebe.putExtra("lembrete", mensagem);
                setResult(RESULT_OK, recebe);
                finish();

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

