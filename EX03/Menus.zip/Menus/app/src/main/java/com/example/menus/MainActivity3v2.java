package com.example.menus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3v2 extends AppCompatActivity {
    private TextView usuario;
    private String usu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity3v2);
        usuario = findViewById(R.id.usuario);
        getSupportActionBar().hide();

        Bundle dados = getIntent().getExtras();

        if (dados != null){
            usu = dados.getString("login");
            usuario.setText(usu);
        }
    }
}