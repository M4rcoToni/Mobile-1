package com.example.geradordeqr;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.content.FileProvider;
import androidx.core.view.MenuItemCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import net.glxn.qrgen.android.QRCode;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private ImageView qr;
    private EditText texto;
    private Button criar;
    private String textinho;
    private Intent intent;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        qr = findViewById(R.id.qr);
        texto = findViewById(R.id.texto);
        criar = findViewById(R.id.criarqr);
        criar.setOnClickListener(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.share){

            if ( texto.getText().toString().length() >0){

                Toast.makeText(getApplicationContext(), "Clicou", Toast.LENGTH_SHORT).show();
                Bitmap myBitmap = QRCode.from(texto.getText().toString()).bitmap();
                qr.setImageBitmap(myBitmap);

                shareImage(myBitmap);
                return  true;
            }else{
                Toast.makeText(getApplicationContext(), "Digite antes de compartilhar", Toast.LENGTH_SHORT).show();
            }
        }else if(id == android.R.id.home){
            finish();
            return  true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem itemshare = menu.findItem(R.id.share);
        MenuItem itemsearch = menu.findItem(R.id.search);
        

        //pesquisa
        SearchView search = (SearchView) itemsearch.getActionView();
        search.setOnQueryTextListener(onSearch());
        // black bitmap
        Bitmap.Config conf = Bitmap.Config.ARGB_8888;
        Bitmap myBitmap = Bitmap.createBitmap(250 , 250 ,conf);
        qr.setImageBitmap(myBitmap);


        //crio bitmap compartilhavel
        ShareActionProvider share = (ShareActionProvider) MenuItemCompat.getActionProvider(itemshare);
        BitmapDrawable bitmapDrawable = (BitmapDrawable) qr.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

        share.setShareIntent(shareImage(bitmap));
        return true;
    }

    private SearchView.OnQueryTextListener onSearch() {
        return  new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                Toast.makeText(getApplicationContext(), "Buscando: "+s, Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        };
    }

    private Uri getmageToShare(Bitmap bitmap) {
        //configuração da imagem
        File imagefolder = new File(getCacheDir(), "images");
        Uri uri = null;
        try {
            imagefolder.mkdirs();
            File file = new File(imagefolder, "shared_image.png");
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, outputStream);
            outputStream.flush();
            outputStream.close();
            uri = FileProvider.getUriForFile(this, "com.anni.shareimage.fileprovider", file);
        } catch (Exception e) {
            Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return uri;
    }


    private Intent shareImage(Bitmap bitmap) {
        //intent com a imagem

        Uri uri = getmageToShare(bitmap);//config image

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");

        intent.setType("image/png");
        //startActivity(Intent.createChooser(intent, "Share"));
        return intent;
    }

    @Override
    public void onClick(View v) {

        if (texto.getText().toString().length() != 0){
            Bitmap myBitmap = QRCode.from(texto.getText().toString()).bitmap();
            qr.setImageBitmap(myBitmap);

        }else{
            Toast.makeText(getApplicationContext(), "Digite Antes de Gerar", Toast.LENGTH_SHORT).show();
        }

    }
}