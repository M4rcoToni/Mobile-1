package com.example.cambio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity  implements View.OnClickListener{
    private TextView texto;
    private TextView sigla1;
    private TextView sigla2;

    private EditText conversao1;
    private EditText conversao2;

    private Button botao;
    private Button usd;
    private Button brl;
    private Button uyu;
    private Button trade;

    private TextView cdate;
    private String date;

    private double conv1;
    private double conv2;

    private double usdbrl;
    private double usduyu;
    private double brlusd;
    private double brluyu;
    private double uyuusd;
    private double uyubrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botao = findViewById(R.id.botao);
        usd = findViewById(R.id.usd);
        brl = findViewById(R.id.brl);
        uyu = findViewById(R.id.uyu);
        trade = findViewById(R.id.trade);
        cdate = findViewById(R.id.data);
        texto = findViewById(R.id.moedas);

        sigla1 = findViewById(R.id.sigla1);
        sigla2 = findViewById(R.id.sigla2);

        conversao1 = findViewById(R.id.coversao1);
        conversao2 = findViewById(R.id.coversao2);

        botao.setOnClickListener(this);

        trade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sig = sigla2.getText().toString();
                sigla2.setText(sigla1.getText().toString());
                sigla1.setText(sig);
            }
        });

        usd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sigla1.setText("USD");
            }
        });
        brl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sigla1.setText("BRL");
            }
        });
        uyu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sigla1.setText("UYU");
            }
        });

        getSupportActionBar().hide();
        executeAPI();

    }
    public void Cambiar(){
        DecimalFormat formatador = new DecimalFormat("0.00");
        conv1 = Double.parseDouble(conversao1.getText().toString());
        if(sigla1.getText().toString().equals("USD") && sigla2.getText().toString().equals("BRL")){
            conversao2.setText(""+formatador.format(conv1*usdbrl));
        }else if(sigla1.getText().toString().equals("USD") && sigla2.getText().toString().equals("UYU")){
            conversao2.setText(""+formatador.format(conv1*usduyu));

        }else if(sigla1.getText().toString().equals("BRL") && sigla2.getText().toString().equals("USD")){
            conversao2.setText(""+formatador.format(conv1*brlusd));
        }else if(sigla1.getText().toString().equals("BRL") && sigla2.getText().toString().equals("UYU")){
            conversao2.setText(""+formatador.format(conv1*brluyu));

        }else if(sigla1.getText().toString().equals("UYU") && sigla2.getText().toString().equals("USD")){
            conversao2.setText(""+formatador.format(conv1*uyuusd));
        }else if(sigla1.getText().toString().equals("UYU") && sigla2.getText().toString().equals("BRL")){
            conversao2.setText(""+formatador.format(conv1*uyubrl));
        }
    }
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.botao){
            Cambiar();
        }
    }
    public void executeAPI(){
        String url = "https://economia.awesomeapi.com.br/last/USD-BRL,USD-UYU,BRL-USD,BRL-UYU,UYU-USD,UYU-BRL";
        tarefa t = new tarefa();
        t.execute(url);
    }

    class tarefa extends AsyncTask<String, Void ,String>{
        @Override
        protected void onPostExecute(String p) {
            super.onPostExecute(p);
            JSONObject jmain = null;
            JSONObject jopen = null;

            try {
                jmain = new JSONObject(p.toString());

                jopen = new JSONObject(jmain.getString("USDBRL"));
                usdbrl = Double.parseDouble(jopen.getString("high"));

                jopen = new JSONObject(jmain.getString("USDUYU"));
                usduyu = Double.parseDouble(jopen.getString("high"));

                jopen = new JSONObject(jmain.getString("BRLUSD"));
                brlusd = Double.parseDouble(jopen.getString("high"));

                jopen = new JSONObject(jmain.getString("BRLUYU"));
                brluyu = Double.parseDouble(jopen.getString("high"));

                jopen = new JSONObject(jmain.getString("UYUUSD"));
                uyuusd = Double.parseDouble(jopen.getString("high"));

                jopen = new JSONObject(jmain.getString("UYUBRL"));
                uyubrl = Double.parseDouble(jopen.getString("high"));

                //atualiza a data
                date = jopen.getString("create_date");
                cdate.setText("Atualizado em "+date);

                //texto.setText(jopen.getString("high"));
            }catch(JSONException e){
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            StringBuffer str = new StringBuffer();
            try {
                URL url2 = new URL(strings[0]);
                HttpURLConnection coenxao = (HttpURLConnection) url2.openConnection();
                InputStream input = coenxao.getInputStream();
                InputStreamReader reader = new InputStreamReader(input);
                BufferedReader leitura = new BufferedReader(reader);
                String s;
                if((s=leitura.readLine())!= null){
                    str.append(s);
                }
                //TESTE
                System.out.println("##############"+str.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return str.toString();
        }
    }
}












