package com.example.alterar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class lembrete extends AppCompatActivity {
    private EditText lembrete;
    private Button define;
    private String mensagem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lembrete);
        lembrete = findViewById(R.id.lembrete);
        define = findViewById(R.id.definir);
        getSupportActionBar().hide();

        define.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mensagem = lembrete.getText().toString();
                Intent recebe = new Intent();
                recebe.putExtra("lembrete", mensagem);
                setResult(RESULT_OK, recebe);
                finish();

            }
        });
    }
}