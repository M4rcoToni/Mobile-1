package com.example.welcome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivityWelcome extends AppCompatActivity {
    private TextView usuario;
    private String usu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_welcome);
        usuario = findViewById(R.id.usuario);
        getSupportActionBar().hide();

        Bundle dados = getIntent().getExtras();

        if (dados != null){
            usu = dados.getString("login");
            usuario.setText(usu);
        }

    }

}