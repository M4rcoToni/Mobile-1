package com.example.welcome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText nome;
    private EditText curso;
    private Button salvar;
    private Button buscar;
    private estudanteDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        nome = findViewById(R.id.nome);
        curso = findViewById(R.id.curso);
        salvar = findViewById(R.id.salvar);
        buscar = findViewById(R.id.buscar);

        salvar.setOnClickListener(this);
        buscar.setOnClickListener(this);
        db = new estudanteDB(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.salvar){
            estudante e = new estudante();
            e.setNome(nome.getText().toString().trim());
            e.setCurso(curso.getText().toString().trim());
            db.save(e);
            Toast.makeText(this, "Salvo com Sucesso!!!", Toast.LENGTH_LONG).show();
            //codigo para guardar
        }
        else if(v.getId()==R.id.buscar){
            //codigo para buscar
            List<estudante> elista = db.findAll();
            for(int i=0; i<elista.size(); i ++){
                System.out.println("ID: "+elista.get(i).getId() + "  Nome: "+ elista.get(i).getNome()+ "  Curso: "+ elista.get(i).getCurso());
            }
            Intent i  = new Intent(getApplicationContext(), Cadastrados.class);
            i.putExtra("objlist", (Serializable) elista);
            startActivity(i);

        }
    }

}