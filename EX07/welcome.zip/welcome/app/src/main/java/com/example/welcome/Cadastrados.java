package com.example.welcome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class Cadastrados extends AppCompatActivity {
    private ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrados);
        getSupportActionBar().hide();

        list = findViewById(R.id.elista);
        List<estudante> elista = (List<estudante>) getIntent().getSerializableExtra("objlist");
        String[] array = new String[elista.size()];

        for (int i = 0 ; i<elista.size(); i++){
            array[i] = (String) "ID: "+elista.get(i).getId() + "   Nome: "+ elista.get(i).getNome()+ "  Curso: "+ elista.get(i).getCurso();
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,array);

        list.setAdapter(adapter);
    }
}