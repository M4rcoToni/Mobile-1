package com.example.fragtabs;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Configuration config = getResources().getConfiguration();
        if (config.smallestScreenWidthDp<720){
            ActionBar actbar= getSupportActionBar(); //resgato o menu
            actbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS); //comportamento

            ActionBar.Tab tab1 = actbar.newTab().setText("Maça"); //nome
            tab1.setTabListener(new MyTabListener( new Fragmento1())); //add evento
            actbar.addTab(tab1);

            ActionBar.Tab tab2 = actbar.newTab().setText("Banana"); //nome
            tab2.setTabListener(new MyTabListener( new Fragmento2())); //add evento
            actbar.addTab(tab2); // add na acction bar

            ActionBar.Tab tab3 = actbar.newTab().setText("Queijo"); //nome
            tab3.setTabListener(new MyTabListener( new Fragmento3())); //add evento
            actbar.addTab(tab3);
        }
    }
}