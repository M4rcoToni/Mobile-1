package com.example.lay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText login;
    private EditText senha;
    private Button continuar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senha);
        continuar = findViewById(R.id.cont);
        continuar.setOnClickListener(this);
        getSupportActionBar().hide();

    }

    @Override
    public void onClick(View v) {
        if (login.getText().toString().equals("a") && senha.getText().toString().equals("a")){
            Intent home = new Intent( getApplicationContext(), HomeActivity.class);
            startActivity(home);
        }else{
            Toast.makeText(getApplicationContext(), "Login ou Senha Incorretos!", Toast.LENGTH_LONG).show();
        }
    }
}