package com.example.parte1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    private TextView texto;
    private EditText campo;
    private Button gerar;
    private Button mostrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.campo);
        texto = findViewById(R.id.texto);
        gerar = findViewById(R.id.bt_gerar);
        mostrar = findViewById(R.id.bt_natela);
        getSupportActionBar().hide(); //retira aba do top
        gerar.setOnClickListener(this);
        mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = campo.getText().toString();
                Toast.makeText(getApplicationContext(), texto, Toast.LENGTH_LONG).show(); //texto no canto inferior
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bt_gerar) {
            if(campo.getText().length() >0){
                String digitado = campo.getText().toString();
                texto.setText(digitado);
            }else{
                Toast.makeText(getApplicationContext(), "Digite seu texto e toque novamente", Toast.LENGTH_LONG).show(); //texto no canto inferior
            }

        }
    }
}